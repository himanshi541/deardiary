window.addEventListener("load", function () {
  // Wait 2.5 seconds before showing main content
  setTimeout(function () {
    document.getElementById("loader").style.display = "none";
    document.getElementById("main-content").style.display = "block";
  }, 2500); // 2500ms = 2.5 seconds
});
